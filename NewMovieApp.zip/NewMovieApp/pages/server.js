import { createServer, Model } from "miragejs"

const seats = [
    {
        "id": "1",
        "booked": false,
        "disabled": false
    },
    {
        "id": "2",
        "booked": false,
        "disabled": false
    },
    {
        "id": "3",
        "booked": false,
        "disabled": false
    },
    {
        "id": "4",
        "booked": false,
        "disabled": false
    },
    {
        "id": "5",
        "booked": false,
        "disabled": false
    },
    {
        "id": "6",
        "booked": false,
        "disabled": false
    },
    {
        "id": "7",
        "booked": false,
        "disabled": false
    },
    {
        "id": "8",
        "booked": false,
        "disabled": false
    },
    {
        "id": "9",
        "booked": false,
        "disabled": false
    },
    {
        "id": "10",
        "booked": false,
        "disabled": false
    },
    {
        "id": "11",
        "booked": false,
        "disabled": false
    },
    {
        "id": "12",
        "booked": false,
        "disabled": false
    }
];
const rows = [
    {
        "rowid": "A",
        "price": 100
    },
    {
        "rowid": "B",
        "price": 100
    },
    {
        "rowid": "C",
        "price": 200
    },
    {
        "rowid": 'D',
        "price": 200
    },
    {
        "rowid": 'E',
        "price": 300
    },
    {
        "rowid": 'F',
        "price": 300
    },
    {
        "rowid": 'G',
        "price": 300
    },
    {
        "rowid": 'H',
        "price": 300
    },

]
const movies = [
    {
        "id": 1,
        "name": "Notebook",
        "date": "16 Jun",
        "imgpath": "/images/notebook.jpg"
    },
    {
        "id": 2,
        "name": "Avenger",
        "date": "16 Jun",
        "imgpath": "/images/avenger.jpg"
    },
    {
        "id": 3,
        "name": "Spiderman",
        "date": "16 Jun",
        "imgpath": "/images/spider.jpg"
    },
    {
        "id": 4,
        "name": "Lion King",
        "date": "16 Jun",
        "imgpath": "/images/lion.jpg"
    },
    {
        "id": 5,
        "name": "Captain Marvel",
        "date": "16 Jun",
        "imgpath": "/images/captain.jpg"
    },
    {
        "id": 6,
        "name": "Toy Story",
        "date": "16 Jun",
        "imgpath": "/images/toy.jpg"
    },
];

export function makeServer({ environment = "test" } = {}) {
    let server = createServer({
        environment,

        models: {
            seats: Model,
            movies: Model,
            rows: Model
        },

        seeds(server) {
            for (let i = 0; i < seats.length; i++) {
                server.create("seat", seats[i])

            }
            for (let i = 0; i < rows.length; i++) {
                server.create("row", rows[i])

            }
            for (let i = 0; i < movies.length; i++) {
                server.create("movie", movies[i])

            }
        },

        routes() {
            this.namespace = "api";

            this.get("/movies", (schema) => {
                return schema.movies.all()
            })

            this.get("/rows", (schema) => {
                return schema.rows.all()
            })
            this.get("/seats", (schema) => {
                return schema.seats.all()
            })
            this.put("/seats/:id", function (schema, request) {
                const parsedData = JSON.parse(request.requestBody)
                console.log(parsedData);
                let id = request.params.id
                return schema.tickets.find(id).update(parsedData)

            })
            this.namespace = ""
            this.passthrough()
        },
    })

    return server
}
