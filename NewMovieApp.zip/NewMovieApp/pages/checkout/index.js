import * as React from "react";
import { useState, useEffect } from "react";
import Card from "@mui/material/Card";
import Box from '@mui/material/Box';
import CardContent from "@mui/material/CardContent";

import Typography from "@mui/material/Typography";

export async function getServerSideProps(context) {
  console.log(context.query)
  // returns { id: episode.itunes.episode, title: episode.title}


  //you can make DB queries using the data in context.query
  return {
    props: {

      bookiename: context.query.bookiename,

      seatsbooked: context.query.seatsbooked,
      totalamount: context.query.totalamount,
    }
  }
}

export default function Checkout(props) {
  const [currentBooking, setCurrentBooking] = useState({});

  useEffect(() => {
    setCurrentBooking(localStorage.getItem("bookedItem"));
    console.log(currentBooking);
  }, []);
  return (
    <div style={{
      position: 'absolute', left: '50%', top: '50%',
      transform: 'translate(-50%, -50%)'
    }}>
      <Card sx={{
        width: 300,
        height: 300, backgroundColor: 'green', border: 1, align: "center"
      }} align="center">
        <CardContent>
          <Typography sx={{ fontSize: 18 }} >
            <h2>Ticket Booked Successfully!!!!</h2>
          </Typography>
          <Typography sx={{ fontSize: 16 }} color="text.secondary" gutterBottom>
            <h3>Booking Details:</h3>
          </Typography>
          <Typography sx={{ fontSize: 14 }} color="text.secondary">Name:
            {props.bookiename}
          </Typography>

          <Typography sx={{ fontSize: 14 }} color="text.secondary">Ticket Nos:
            {
              props.seatsbooked.map((item) => <span>{item} {','}</span>)
            }
          </Typography>
          <Typography sx={{ fontSize: 14 }} color="text.secondary">Total Amount:
            {props.totalamount}
          </Typography>
        </CardContent>
      </Card>
    </div>

  );
}
