import Link from 'next/link';
import React, { useState, useEffect } from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import { Button, CardActionArea, CardActions } from '@mui/material';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';

export default function Movie(item) {
    const [movies, setMovies] = useState([]);


    useEffect(() => {
        fetch("/api/movies")
            .then((response) => response.json())
            .then((json) => setMovies(json.movies))
    })

    return (
        <div>
            <Box
                sx={{

                    height: 60,
                    backgroundColor: 'primary.dark',

                }}
            ><h2 align="center" justifyContent="center" color="Brown">MOVIE PAGE</h2></Box><br /><br />
            <Grid container spacing={2} align="center">
                {movies.map((ele) =>
                    <Grid key={ele.id} card xs={4}>
                        <Card sx={{ maxWidth: 345 }}>
                            <CardActionArea>
                                <CardMedia
                                    component="img"
                                    height="140"
                                    image={ele.imgpath}
                                    alt={ele.name}
                                />
                                <CardContent>
                                    <Typography gutterBottom variant="h5" component="div">
                                        {ele.name}
                                    </Typography>
                                    <Typography gutterBottom variant="h5" component="div">
                                        {ele.date}
                                    </Typography>
                                </CardContent>
                            </CardActionArea>
                            <CardActions>
                                <Link href="/seats" passHref>
                                    <Button size="small" color="success" >
                                        Book Now
                                    </Button>
                                </Link>
                            </CardActions>
                        </Card><br />
                    </Grid>
                )
                }
            </Grid>

        </div>
    )
}





