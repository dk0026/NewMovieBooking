import Head from "next/head";
import Image from "next/image";
import React, { useState } from "react";
import Grid from "@material-ui/core/Grid";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableRow from "@mui/material/TableRow";
import WeekendIcon from "@mui/icons-material/Weekend";
import Paper from "@mui/material/Paper";
import { useEffect } from "react";
import axios from "axios";
import Box from "@mui/material/Box";
import Link from "next/link";

const defaultValues = {
  name: "",
};

const bookingInfo = {
  bookiename: "",
  seatsbooked: [],
  totalamount: 0
};

export default function Seats() {
  const [formValues, setFormValues] = useState(defaultValues);
  const [rows, setRows] = useState([]);
  const [seats, setSeats] = useState([]);
  const [booked, setBooked] = useState(false);
  const [select, setSelect] = useState(false);
  const [inputSeats, setInputSeats] = useState(bookingInfo);

  useEffect(() => {
    fetch("/api/rows")
      .then((response) => response.json())
      .then((json) => setRows(json.rows));
    fetch("/api/seats")
      .then((response) => response.json())
      .then((json) => setSeats(json.seats));
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormValues({
      ...formValues,
      [name]: value,
    });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(formValues);
    setSelect(!select);
  };
  function handleSelection(seatId, rowId, price) {
    event.preventDefault();
    const numberOfSeats = formValues.seatsno;
    const count = numberOfSeats;
    if (select == true) {

      event.target.style.color = "blue";
      const seat = rowId + seatId; //A1
      setInputSeats({
        ...inputSeats,
        bookiename: formValues.name,

        seatsbooked: !!inputSeats.seatsbooked
          ? [...inputSeats.seatsbooked, seat]
          : [seat],
        totalamount: inputSeats.totalamount + price,
      });

      axios
        .put(`/seats/${seatId}`, { booked: true })
        .then((data) => {
          setBooked(!booked);
        })
        .catch((err) => {
          console.log(err);
        });


    } else {
      alert("Please Enter Your Name & Start Selecting");
    }
  }


  return (
    <div>
      <form onSubmit={handleSubmit}>
        <Grid
          container
          alignItems="center"
          justifyContent="center"
          direction="column"
        >
          <Grid item>
            <TextField
              id="name-input"
              name="name"
              label="Name"
              type="text"
              value={formValues.name}
              onChange={handleInputChange}
            />
          </Grid>

          <br />
          <Button variant="contained" color="default" type="submit">
            Start selecting
          </Button>
        </Grid>
      </form>

      <Box
        sx={{
          height: 60,
          backgroundColor: "primary.dark",
        }}
      >
        <h2 align="center" color="Brown">
          SCREEN
        </h2>
      </Box>

      <TableContainer component={Paper}>
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableBody>
            <TableRow
              sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
            >
              <TableCell></TableCell>
              {seats.map((seat) => (
                <TableCell key={seat.id} component="th" scope="row">
                  {seat.id}
                </TableCell>
              ))}
            </TableRow>

            {rows.map((row) => (
              <TableRow
                key={row.rowid}
                sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
              >
                <TableCell component="th" scope="row">
                  {row.rowid}
                </TableCell>
                {seats.map((seat) => (
                  <TableCell key={seat.id} component="th" scope="row">
                    <WeekendIcon
                      fontSize="large"
                      onClick={() => handleSelection(seat.id, row.rowid, row.price)}
                    ></WeekendIcon>
                  </TableCell>
                ))}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <br />
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >

        <Link
          href={{
            pathname: "checkout",
            query: {
              bookiename: inputSeats.bookiename,
              seatsbooked: inputSeats.seatsbooked,
              totalamount: inputSeats.totalamount,
            }
          }}
          as={`checkout/`}
        >
          <Button variant="contained" color="primary">
            Confirm Ticket
          </Button>
        </Link>
      </div>
    </div>
  );
}
